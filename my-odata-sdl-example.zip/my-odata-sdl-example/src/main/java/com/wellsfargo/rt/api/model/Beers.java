package com.wellsfargo.rt.api.model;

import com.sdl.odata.api.edm.annotations.EdmEntity;
import com.sdl.odata.api.edm.annotations.EdmEntitySet;
import com.sdl.odata.api.edm.annotations.EdmProperty;

@EdmEntity(namespace = "SDL.OData.Example", key = "id", containerName = "SDLExample")
@EdmEntitySet
public class Beers {

	@EdmProperty(name = "id", nullable = false)
	String id;

	@EdmProperty(name = "brewery_id")
	String brewery_id;
	@EdmProperty(name = "name")
	String name;
	@EdmProperty(name = "cat_id")
	String cat_id;
	@EdmProperty(name = "style_id")
	String style_id;
	@EdmProperty(name = "abv")
	String abv;
	@EdmProperty(name = "ibu")
	String ibu;
	@EdmProperty(name = "srm")
	String srm;
	@EdmProperty(name = "upc")
	String upc;
	@EdmProperty(name = "filepath")
	String filepath;
	@EdmProperty(name = "descript")
	String descript;
	@EdmProperty(name = "last_mod")
	String last_mod;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getBrewery_id() {
		return brewery_id;
	}

	public void setBrewery_id(String brewery_id) {
		this.brewery_id = brewery_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCat_id() {
		return cat_id;
	}

	public void setCat_id(String cat_id) {
		this.cat_id = cat_id;
	}

	public String getStyle_id() {
		return style_id;
	}

	public void setStyle_id(String style_id) {
		this.style_id = style_id;
	}

	public String getAbv() {
		return abv;
	}

	public void setAbv(String abv) {
		this.abv = abv;
	}

	public String getIbu() {
		return ibu;
	}

	public void setIbu(String ibu) {
		this.ibu = ibu;
	}

	public String getSrm() {
		return srm;
	}

	public void setSrm(String srm) {
		this.srm = srm;
	}

	public String getUpc() {
		return upc;
	}

	public void setUpc(String upc) {
		this.upc = upc;
	}

	public String getFilepath() {
		return filepath;
	}

	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}

	public String getDescript() {
		return descript;
	}

	public void setDescript(String descript) {
		this.descript = descript;
	}

	public String getLast_mod() {
		return last_mod;
	}

	public void setLast_mod(String last_mod) {
		this.last_mod = last_mod;
	}

}
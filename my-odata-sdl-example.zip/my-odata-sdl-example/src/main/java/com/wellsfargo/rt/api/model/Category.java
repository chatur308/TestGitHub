package com.wellsfargo.rt.api.model;

import com.sdl.odata.api.edm.annotations.EdmEntity;
import com.sdl.odata.api.edm.annotations.EdmEntitySet;
import com.sdl.odata.api.edm.annotations.EdmProperty;

@EdmEntity(namespace = "SDL.OData.Example", key = "id", containerName = "SDLExample")
@EdmEntitySet
public class Category {
	@EdmProperty(name = "id", nullable = false)
	String id;

	@EdmProperty(name = "cat_name")
	String cat_name;
	@EdmProperty(name = "last_mod")
	String last_mod;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCat_name() {
		return cat_name;
	}

	public void setCat_name(String cat_name) {
		this.cat_name = cat_name;
	}

	public String getLast_mod() {
		return last_mod;
	}

	public void setLast_mod(String last_mod) {
		this.last_mod = last_mod;
	}

}

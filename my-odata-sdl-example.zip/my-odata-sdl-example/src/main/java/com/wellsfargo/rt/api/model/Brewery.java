package com.wellsfargo.rt.api.model;

import com.sdl.odata.api.edm.annotations.EdmEntity;
import com.sdl.odata.api.edm.annotations.EdmEntitySet;
import com.sdl.odata.api.edm.annotations.EdmProperty;

@EdmEntity(namespace = "SDL.OData.Example", key = "id", containerName = "SDLExample")
@EdmEntitySet
public class Brewery {

	@EdmProperty(name = "id", nullable = false)
	String id;
	@EdmProperty(name = "name")
	String name;
	@EdmProperty(name = "address1")
	String address1;
	@EdmProperty(name = "address2")
	String address2;
	@EdmProperty(name = "city")
	String city;
	@EdmProperty(name = "state")
	String state;
	@EdmProperty(name = "code")
	String code;
	@EdmProperty(name = "country")
	String country;
	@EdmProperty(name = "phone")
	String phone;
	@EdmProperty(name = "website")
	String website;
	@EdmProperty(name = "filepath")
	String filepath;
	@EdmProperty(name = "descript")
	String descript;
	@EdmProperty(name = "last_mod")
	String last_mod;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getFilepath() {
		return filepath;
	}

	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}

	public String getDescript() {
		return descript;
	}

	public void setDescript(String descript) {
		this.descript = descript;
	}

	public String getLast_mod() {
		return last_mod;
	}

	public void setLast_mod(String last_mod) {
		this.last_mod = last_mod;
	}

}
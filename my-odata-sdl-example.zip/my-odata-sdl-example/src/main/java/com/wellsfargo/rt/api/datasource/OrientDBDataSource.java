package com.wellsfargo.rt.api.datasource;

import org.springframework.stereotype.Component;

import com.sdl.odata.api.ODataException;
import com.sdl.odata.api.edm.model.EntityDataModel;
import com.sdl.odata.api.parser.ODataUri;
import com.sdl.odata.api.processor.datasource.DataSource;
import com.sdl.odata.api.processor.datasource.TransactionalDataSource;
import com.sdl.odata.api.processor.link.ODataLink;

@Component
public class OrientDBDataSource implements DataSource{

	public Object create(ODataUri arg0, Object arg1, EntityDataModel arg2) throws ODataException {
		// TODO Auto-generated method stub
		return null;
	}

	public void createLink(ODataUri arg0, ODataLink arg1, EntityDataModel arg2) throws ODataException {
		// TODO Auto-generated method stub
		
	}

	public void delete(ODataUri arg0, EntityDataModel arg1) throws ODataException {
		// TODO Auto-generated method stub
		
	}

	public void deleteLink(ODataUri arg0, ODataLink arg1, EntityDataModel arg2) throws ODataException {
		// TODO Auto-generated method stub
		
	}

	public TransactionalDataSource startTransaction() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object update(ODataUri arg0, Object arg1, EntityDataModel arg2) throws ODataException {
		// TODO Auto-generated method stub
		return null;
	}
	
}
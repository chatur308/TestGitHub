
package org.me.jersey;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

/** Example resource class hosted at the URI path "/myresource"
 */
@Path("/myresource")
public class MyResource {
    
    /** Method processing HTTP GET requests, producing "text/plain" MIME media
     * type.
     * @return String that will be send back as a response of type "text/plain".
     */
    @GET 
    @Produces("text/plain")
    public String getIt() {
        return "Hi there!";
    }
    
    @GET
	@Produces({ MediaType.APPLICATION_XML, MediaType.TEXT_PLAIN,
		MediaType.APPLICATION_JSON })
	public Response getEntity(@Context final HttpHeaders httpHeaders, @Context final UriInfo uriInfo, @Context HttpServletRequest request,
            @PathParam("navProp") final String navProp, @QueryParam("$inlinecount") final String inlineCount, @QueryParam("$top") final String top,
            @QueryParam("$skip") final String skip, @QueryParam("$filter") final String filter, @QueryParam("$orderby") final String orderBy,
            @QueryParam("$format") final String format, @QueryParam("$callback") final String callback, @QueryParam("$skiptoken") final String skipToken,
            @QueryParam("$expand") final String expand, @QueryParam("$select") final String select) throws Exception  {
				
    	
    	return null;
    	
    }

}

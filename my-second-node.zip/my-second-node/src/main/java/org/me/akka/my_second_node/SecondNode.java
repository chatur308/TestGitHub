package org.me.akka.my_second_node;


import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.actor.Props;
import akka.actor.AbstractActor.Receive;
import akka.cluster.Cluster;
import akka.cluster.ClusterEvent.MemberEvent;
import akka.cluster.ClusterEvent.MemberRemoved;
import akka.cluster.ClusterEvent.MemberUp;
import akka.cluster.ClusterEvent.UnreachableMember;
import akka.cluster.pubsub.DistributedPubSub;
import akka.cluster.pubsub.DistributedPubSubMediator;
import akka.event.Logging;
import akka.event.LoggingAdapter;

public class SecondNode extends AbstractActor {
	 LoggingAdapter log = Logging.getLogger(getContext().system(), this);
	  Cluster cluster = Cluster.get(getContext().system());

	public static void main(String[] args) {
		
		Config config = ConfigFactory.load();
		
		ActorSystem actorSystem = ActorSystem.create("ClusterSystem", config);
		ActorRef actorRef = actorSystem.actorOf(Props.create(SecondNode.class), "clusterListener");
		ActorRef mediator = DistributedPubSub.get(actorSystem).mediator();
		mediator.tell(new DistributedPubSubMediator.Put(actorRef),actorRef);
	}
	
	@Override
	public Receive createReceive() {return receiveBuilder()
		      .match(MemberUp.class, mUp -> {
		          log.info("Member is Up: {}", mUp.member());
		        })
		        .match(UnreachableMember.class, mUnreachable -> {
		          log.info("Member detected as unreachable: {}", mUnreachable.member());
		        })
		        .match(MemberRemoved.class, mRemoved -> {
		          log.info("Member is Removed: {}", mRemoved.member());
		        })
		        .match(MemberEvent.class, message -> {
		          // ignore
		        })
		        .build();}
	
}
